import { Post } from './post';

export const POSTS: Post[] = [
    {
        postid: 3,
        created: 6789,
        modified: 0,
        title: "Title3",
        body: "Body3"},
    {
        postid: 1,
        created: 12345,
        modified: 0,
        title: "Title1",
        body: "Body1"},
    {
        postid: 2,
        created: 6789,
        modified: 0,
        title: "Title2",
        body: "Body2"},

];
